from typing import Dict, Any, Tuple, Optional
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.preprocessing import normalize
import numpy as np

class Matcher:
    def __init__(self, students: list, config: dict):
        self.students = students
        self.config = config
        self._validate_config()
        
        try:
            # Initialize TF-IDF vectorizer and compute goal vectors
            self.tfidf = TfidfVectorizer(stop_words='english', lowercase=True)
            goals = [stu.get("goal", "") for stu in students]  # Use .get() for safety
            
            if not goals or all(not goal.strip() for goal in goals):
                raise ValueError("No valid goals found in student data")
                
            self.goal_vectors = self.tfidf.fit_transform(goals)
            self.goal_vectors = normalize(self.goal_vectors)
        except Exception as e:
            raise ValueError(f"Failed to initialize TF-IDF vectorizer: {e}")

    def _validate_config(self):
        """Validate that all required configuration keys are present"""
        required_keys = [
            "boost_goal_match", "study_time_weight",
            "study_type_weight", "personality_weight"
        ]
        for key in required_keys:
            if key not in self.config:
                raise ValueError(f"Missing required config key: {key}")

    def _compute_personality_overlap(self, p1: list, p2: list) -> Tuple[float, list]:
        """Compute Jaccard similarity and overlap for personality traits"""
        if not p1 or not p2:
            return (0.0, [])
            
        set1, set2 = set(p1), set(p2)
        intersection = set1 & set2
        union = set1 | set2
        
        if not union:
            return (0.0, [])
        
        jaccard_score = len(intersection) / len(union)
        return (jaccard_score, list(intersection))

    def find_best_match(self, input_student: Dict[str, Any]) -> Tuple[Optional[Dict], float, Dict]:
        """Find the best matching study buddy for the input student"""
        try:
            best_score = 0.0
            best_match = None
            reasoning = {}
            threshold = self.config.get("minimum_match_score", 0.6)

            # Validate input
            if not input_student.get("goal"):
                return None, 0.0, {"error": "No goal provided"}

            # Precompute input features once
            input_goal = input_student["goal"]
            
            # FIX: Use transform (not fit_transform) to maintain same vocabulary
            input_vec = self.tfidf.transform([input_goal])
            input_vec = normalize(input_vec)
            
            input_time = input_student.get("preferred_study_time", "")
            input_type = input_student.get("study_type", "")
            input_personality = input_student.get("personality", [])

            # Vectorized cosine similarity for all candidates
            goal_similarities = cosine_similarity(input_vec, self.goal_vectors).flatten()

            for idx, candidate in enumerate(self.students):
                # Skip self-matching
                if candidate.get("student_id") == input_student.get("student_id"):
                    continue

                # Use precomputed goal similarity
                goal_sim = float(goal_similarities[idx])

                # Binary matches
                time_match = (input_time == candidate.get("preferred_study_time", ""))
                type_match = (input_type == candidate.get("study_type", ""))

                # Personality overlap using Jaccard similarity
                personality_score, personality_overlap = self._compute_personality_overlap(
                    input_personality, candidate.get("personality", [])
                )

                # Calculate weighted score
                weighted_score = (
                    goal_sim * self.config["boost_goal_match"] +
                    (1.0 if time_match else 0.0) * self.config["study_time_weight"] +
                    (1.0 if type_match else 0.0) * self.config["study_type_weight"] +
                    personality_score * self.config["personality_weight"]
                )

                # Track best match
                if weighted_score > best_score:
                    best_score = weighted_score
                    best_match = candidate
                    reasoning = {
                        "goal_similarity": round(goal_sim, 2),
                        "study_time_match": time_match,
                        "study_type_match": type_match,
                        "personality_overlap": personality_overlap
                    }

            # Normalize best score to 0-1 range
            max_possible = (
                self.config["boost_goal_match"] +
                self.config["study_time_weight"] +
                self.config["study_type_weight"] +
                self.config["personality_weight"]
            )
            normalized_score = best_score / max_possible if max_possible > 0 else 0

            # Return match only if it meets the threshold
            if normalized_score >= threshold:
                return best_match, round(normalized_score, 2), reasoning
            else:
                return None, 0.0, reasoning
                
        except Exception as e:
            return None, 0.0, {"error": f"Matching failed: {str(e)}"}
