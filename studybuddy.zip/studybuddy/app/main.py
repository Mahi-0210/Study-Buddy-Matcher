from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
from app.matcher import Matcher
import json
from pathlib import Path

# Define Pydantic model for input validation
class MatchRequest(BaseModel):
    student_id: str
    goal: str
    preferred_study_time: str
    study_type: str
    personality: List[str]  # Fixed: List[str] instead of list[str]
    # Optional fields (align with your dataset)
    year: Optional[str] = None  # Fixed: Optional[str] instead of str | None
    branch: Optional[str] = None
    location: Optional[str] = None
    languages_known: Optional[List[str]] = None

app = FastAPI(title="Study Buddy Matching API", version="1.0.0")

# Enable CORS for frontend access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Change to your frontend URL in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def validate_config(config):
    """Validate configuration file has all required keys"""
    required_keys = [
        "version", "minimum_match_score", "boost_goal_match",
        "study_time_weight", "study_type_weight", "personality_weight"
    ]
    for key in required_keys:
        if key not in config:
            raise ValueError(f"Missing required config key: {key}")
    
    if not (0 <= config["minimum_match_score"] <= 1):
        raise ValueError("minimum_match_score must be between 0 and 1")

# Get project root relative to this file
PROJECT_ROOT = Path(__file__).parent.parent  # Fixed: __file__ instead of _file_
data_path = PROJECT_ROOT / "data" / "students.json"
config_path = PROJECT_ROOT / "config.json"

try:
    # Load data and config
    with open(data_path, encoding="utf-8") as f:
        students = json.load(f)
    with open(config_path, encoding="utf-8") as f:
        config = json.load(f)
    
    # Validate configuration
    validate_config(config)
    
    # Initialize matcher
    matcher = Matcher(students, config)
    
    # Attach to app.state for access
    app.state.config = config
    app.state.matcher = matcher
    app.state.students = students

except FileNotFoundError as e:
    raise RuntimeError(f"Required file not found: {e}")
except json.JSONDecodeError as e:
    raise RuntimeError(f"Invalid JSON in configuration file: {e}")
except Exception as e:
    raise RuntimeError(f"Failed to initialize application: {e}")

@app.get("/health")
def health_check() -> dict:
    """Health check endpoint"""
    return {"status": "ok"}

@app.get("/version")
def get_version() -> dict:
    """Get version and configuration details"""
    return {
        "version": config.get("version", "1.0.0"),
        "config": config,
        "total_students": len(students)
    }

@app.get("/")
def root() -> dict:
    """Root endpoint with welcome message"""
    return {"message": "Welcome to the Study Buddy API!"}

@app.post("/match")
def find_study_buddy(request: MatchRequest) -> dict:
    """Find the best study buddy match for a student"""
    try:
        best_match, score, reasoning = app.state.matcher.find_best_match(request.model_dump())
        
        # Ensure score is 0.0 and matched_student_id is None if no match
        if best_match is None:
            score = 0.0
            
        return {
            "matched_student_id": best_match.get("student_id") if best_match else None,
            "match_score": score,
            "reasoning": reasoning
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Matching failed: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
