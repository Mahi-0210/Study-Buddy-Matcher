import sys
import os
import pytest
import time
from fastapi.testclient import TestClient

# Add project root to Python path
# Change the import path:
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))  # Remove 'study-buddy'

from app.main import app

client = TestClient(app)

# Valid student profiles for testing
VALID_PROFILE_1 = {
    "student_id": "stu_test1",
    "goal": "Crack GATE 2025",
    "preferred_study_time": "early_morning",
    "study_type": "visual",
    "personality": ["focused", "introvert"],
    "year": "second_year",
    "branch": "Computer Science",
    "location": "Delhi",
    "languages_known": ["English", "Hindi"]
}

VALID_PROFILE_2 = {
    "student_id": "stu_test2",
    "goal": "Win coding hackathon",
    "preferred_study_time": "late_night",
    "study_type": "project_based",
    "personality": ["creative", "competitive"],
    "year": "third_year",
    "branch": "Electronics",
    "location": "Mumbai"
}

def test_valid_match_response_structure():
    response = client.post("/match", json=VALID_PROFILE_1)
    assert response.status_code == 200
    data = response.json()
    
    assert "matched_student_id" in data
    assert "match_score" in data
    assert "reasoning" in data
    assert 0 <= data["match_score"] <= 1
    
    reasoning = data["reasoning"]
    assert "goal_similarity" in reasoning
    assert "study_time_match" in reasoning
    assert "study_type_match" in reasoning
    assert "personality_overlap" in reasoning

def test_second_valid_profile():
    response = client.post("/match", json=VALID_PROFILE_2)
    assert response.status_code == 200
    data = response.json()
    assert data["match_score"] >= 0

def test_missing_required_fields():
    invalid_profile = VALID_PROFILE_1.copy()
    del invalid_profile["personality"]
    response = client.post("/match", json=invalid_profile)
    assert response.status_code == 422

def test_no_match_found():
    # Save original state
    original_config = app.state.config.copy()
    original_matcher = app.state.matcher
    
    try:
        # Force no matches
        app.state.config["minimum_match_score"] = 1.0
        from app.matcher import Matcher
        app.state.matcher = Matcher(app.state.matcher.students, app.state.config)
        
        response = client.post("/match", json=VALID_PROFILE_1)
        data = response.json()
        
        assert data["matched_student_id"] is None
        assert data["match_score"] == 0.0
    finally:
        # Restore original state
        app.state.config = original_config
        app.state.matcher = original_matcher

def test_performance():
    # Save original state
    original_students = app.state.matcher.students.copy()
    original_vectors = app.state.matcher.goal_vectors
    
    try:
        # Generate test candidates
        test_candidates = [{
            "student_id": f"stu_perf_{i}",
            "goal": f"Goal {i}",
            "preferred_study_time": "flexible",
            "study_type": "visual",
            "personality": ["perf_trait"]
        } for i in range(1000)]
        
        # Update matcher with test data
        app.state.matcher.students.extend(test_candidates)
        app.state.matcher.goal_vectors = app.state.matcher.tfidf.fit_transform(
            [stu["goal"] for stu in app.state.matcher.students]
        )
        
        # Test performance
        start_time = time.time()
        response = client.post("/match", json=VALID_PROFILE_1)
        elapsed = time.time() - start_time
        
        assert response.status_code == 200
        assert elapsed < 1.0, f"Response time {elapsed:.2f}s exceeds 1 second"
    finally:
        # Restore original state
        app.state.matcher.students = original_students
        app.state.matcher.goal_vectors = original_vectors
