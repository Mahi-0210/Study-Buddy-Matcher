import sys
import os
import pytest
import time
from fastapi.testclient import TestClient

# Add project root to Python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app.main import app

client = TestClient(app)

# Valid student profiles for testing
VALID_PROFILE_1 = {
    "student_id": "stu_test1",
    "goal": "Crack GATE 2025",
    "preferred_study_time": "early_morning",
    "study_type": "visual",
    "personality": ["focused", "introvert"],
    "year": "second_year",
    "branch": "Computer Science",
    "location": "Delhi",
    "languages_known": ["English", "Hindi"]
}

VALID_PROFILE_2 = {
    "student_id": "stu_test2",
    "goal": "Win coding hackathon",
    "preferred_study_time": "late_night",
    "study_type": "project_based",
    "personality": ["creative", "competitive"],
    "year": "third_year",
    "branch": "Electronics",
    "location": "Mumbai"
}

def test_health_endpoint():
    """Test health check endpoint"""
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}

def test_version_endpoint():
    """Test version endpoint"""
    response = client.get("/version")
    assert response.status_code == 200
    data = response.json()
    assert "version" in data
    assert "config" in data
    assert "total_students" in data

def test_valid_match_response_structure():
    """Test that valid input returns proper response structure"""
    response = client.post("/match", json=VALID_PROFILE_1)
    assert response.status_code == 200
    data = response.json()
    
    # Check required fields
    assert "matched_student_id" in data
    assert "match_score" in data
    assert "reasoning" in data
    assert 0 <= data["match_score"] <= 1
    
    # Check reasoning structure - handle both success and error cases
    reasoning = data["reasoning"]
    if "error" not in reasoning:
        # Normal success case - match found
        assert "goal_similarity" in reasoning
        assert "study_time_match" in reasoning
        assert "study_type_match" in reasoning
        assert "personality_overlap" in reasoning
        assert isinstance(reasoning["goal_similarity"], (int, float))
        assert isinstance(reasoning["study_time_match"], bool)
        assert isinstance(reasoning["study_type_match"], bool)
        assert isinstance(reasoning["personality_overlap"], list)
    else:
        # Error case or no match case
        assert isinstance(reasoning, dict)
        # Could be error or just no match message

def test_second_valid_profile():
    """Test second profile returns valid response"""
    response = client.post("/match", json=VALID_PROFILE_2)
    assert response.status_code == 200
    data = response.json()
    
    # Basic structure validation
    assert "matched_student_id" in data
    assert "match_score" in data
    assert "reasoning" in data
    assert 0 <= data["match_score"] <= 1

def test_missing_required_fields():
    """Test that missing required fields return 422"""
    invalid_profile = VALID_PROFILE_1.copy()
    del invalid_profile["personality"]
    response = client.post("/match", json=invalid_profile)
    assert response.status_code == 422

def test_no_match_found():
    """Test behavior when no match meets threshold"""
    # Create a profile that's unlikely to match
    no_match_profile = {
        "student_id": "stu_no_match_test",
        "goal": "Extremely Rare Subject That No One Studies",
        "preferred_study_time": "3am_only",
        "study_type": "telepathic_learning",
        "personality": ["antisocial", "nocturnal", "alien"],
        "year": "tenth_year",
        "branch": "Astrology",
        "location": "Mars"
    }
    
    response = client.post("/match", json=no_match_profile)
    assert response.status_code == 200
    data = response.json()
    
    # Should return null match and 0 score for no match
    assert data["matched_student_id"] is None
    assert data["match_score"] == 0.0
    assert "reasoning" in data

def test_performance():
    """Test that response time is under 1 second for large dataset"""
    start_time = time.time()
    response = client.post("/match", json=VALID_PROFILE_1)
    elapsed = time.time() - start_time
    
    assert response.status_code == 200
    assert elapsed < 1.0, f"Response time {elapsed:.2f}s exceeds 1 second"

def test_score_range_validation():
    """Test that match scores are always in valid range"""
    response = client.post("/match", json=VALID_PROFILE_1)
    assert response.status_code == 200
    data = response.json()
    
    score = data["match_score"]
    assert isinstance(score, (int, float))
    assert 0.0 <= score <= 1.0

def test_reasoning_non_empty():
    """Test that reasoning is never empty"""
    response = client.post("/match", json=VALID_PROFILE_1)
    assert response.status_code == 200
    data = response.json()
    
    reasoning = data["reasoning"]
    assert isinstance(reasoning, dict)
    assert len(reasoning) > 0  # Reasoning should never be empty

def test_consistent_results():
    """Test that same input produces consistent results"""
    response1 = client.post("/match", json=VALID_PROFILE_1)
    response2 = client.post("/match", json=VALID_PROFILE_1)
    
    assert response1.status_code == 200
    assert response2.status_code == 200
    
    data1 = response1.json()
    data2 = response2.json()
    
    # Same input should produce same results
    assert data1["matched_student_id"] == data2["matched_student_id"]
    assert data1["match_score"] == data2["match_score"]

def test_different_profiles_handling():
    """Test that different profiles are handled correctly"""
    response1 = client.post("/match", json=VALID_PROFILE_1)
    response2 = client.post("/match", json=VALID_PROFILE_2)
    
    assert response1.status_code == 200
    assert response2.status_code == 200
    
    # Both should have valid structure
    for response in [response1, response2]:
        data = response.json()
        assert "matched_student_id" in data
        assert "match_score" in data
        assert "reasoning" in data
        assert 0 <= data["match_score"] <= 1
