
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { User, Book, Clock, Settings, Trophy, Users } from "lucide-react";
import { toast } from "sonner";

const Profile = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [profileData, setProfileData] = useState({
    name: "John Doe",
    studentId: "CS2021001",
    year: "3rd Year",
    branch: "Computer Science",
    email: "john.doe@university.edu",
    goals: ["GATE Preparation", "Competitive Programming", "Skill Building"],
    studyTime: "Morning (8-12 PM)",
    studyType: "Discussion Based",
    location: "Library",
    traits: ["Focused", "Analytical", "Motivated", "Organized"]
  });

  const studyHistory = [
    {
      partner: "Alex Johnson",
      subject: "Data Structures",
      duration: "2 weeks",
      status: "Completed",
      rating: 5
    },
    {
      partner: "Sarah Chen",
      subject: "Machine Learning",
      duration: "1 month",
      status: "Ongoing",
      rating: null
    },
    {
      partner: "Raj Patel",
      subject: "System Design",
      duration: "3 weeks",
      status: "Completed",
      rating: 4
    }
  ];

  const achievements = [
    { name: "First Partnership", description: "Completed your first study session", icon: "🤝" },
    { name: "Consistent Learner", description: "5+ successful study partnerships", icon: "📚" },
    { name: "Time Master", description: "Never missed a scheduled session", icon: "⏰" },
    { name: "Goal Achiever", description: "Completed a major academic goal", icon: "🎯" }
  ];

  const handleSave = () => {
    setIsEditing(false);
    toast.success("Profile updated successfully!");
  };

  return (
    <div className="min-h-screen pt-24 pb-12 px-4">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold font-poppins text-gray-900 mb-2">
            My Profile
          </h1>
          <p className="text-gray-600">
            Manage your study preferences and track your progress
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Profile Card */}
          <div className="lg:col-span-1">
            <Card className="bg-white/90 backdrop-blur-sm shadow-xl border-0 sticky top-24">
              <CardHeader className="text-center pb-4">
                <div className="relative inline-block">
                  <img
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face"
                    alt="Profile"
                    className="w-24 h-24 rounded-full mx-auto mb-4 border-4 border-academic-blue/20"
                  />
                  <div className="absolute bottom-4 right-0 bg-success-green text-white rounded-full p-1">
                    <div className="w-3 h-3 rounded-full bg-white"></div>
                  </div>
                </div>
                <CardTitle className="text-xl font-semibold text-gray-900">
                  {profileData.name}
                </CardTitle>
                <p className="text-gray-600">{profileData.year} • {profileData.branch}</p>
                <p className="text-sm text-gray-500">{profileData.email}</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Current Goals</h4>
                    <div className="flex flex-wrap gap-1">
                      {profileData.goals.map((goal, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {goal}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Study Preferences</h4>
                    <div className="space-y-2 text-sm text-gray-600">
                      <div className="flex items-center space-x-2">
                        <Clock className="h-4 w-4" />
                        <span>{profileData.studyTime}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Book className="h-4 w-4" />
                        <span>{profileData.studyType}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Settings className="h-4 w-4" />
                        <span>{profileData.location}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="overview" className="space-y-6">
              <TabsList className="grid w-full grid-cols-4 bg-white/80 backdrop-blur-sm">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="history">History</TabsTrigger>
                <TabsTrigger value="achievements">Achievements</TabsTrigger>
                <TabsTrigger value="settings">Settings</TabsTrigger>
              </TabsList>

              <TabsContent value="overview">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card className="bg-gradient-to-br from-academic-blue to-blue-600 text-white">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-blue-100">Active Partnerships</p>
                          <p className="text-3xl font-bold">3</p>
                        </div>
                        <Users className="h-12 w-12 text-blue-200" />
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-gradient-to-br from-success-green to-green-600 text-white">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-green-100">Completed Sessions</p>
                          <p className="text-3xl font-bold">12</p>
                        </div>
                        <Book className="h-12 w-12 text-green-200" />
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-gradient-to-br from-warm-purple to-purple-600 text-white">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-purple-100">Study Hours</p>
                          <p className="text-3xl font-bold">45</p>
                        </div>
                        <Clock className="h-12 w-12 text-purple-200" />
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-gradient-to-br from-study-orange to-orange-600 text-white">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-orange-100">Goals Achieved</p>
                          <p className="text-3xl font-bold">2</p>
                        </div>
                        <Trophy className="h-12 w-12 text-orange-200" />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="history">
                <Card className="bg-white/90 backdrop-blur-sm shadow-lg border-0">
                  <CardHeader>
                    <CardTitle>Study History</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {studyHistory.map((session, index) => (
                        <div key={index} className="flex items-center justify-between p-4 rounded-lg border bg-gray-50/50">
                          <div className="flex items-center space-x-4">
                            <img
                              src={`https://images.unsplash.com/photo-${index % 2 === 0 ? '1507003211169-0a1dd7228f2d' : '1494790108755-2616b612b577'}?w=50&h=50&fit=crop&crop=face`}
                              alt={session.partner}
                              className="w-10 h-10 rounded-full"
                            />
                            <div>
                              <p className="font-medium text-gray-900">{session.partner}</p>
                              <p className="text-sm text-gray-600">{session.subject}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm text-gray-600">{session.duration}</p>
                            <Badge 
                              variant={session.status === "Completed" ? "default" : "secondary"}
                              className="mt-1"
                            >
                              {session.status}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="achievements">
                <Card className="bg-white/90 backdrop-blur-sm shadow-lg border-0">
                  <CardHeader>
                    <CardTitle>Achievements</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {achievements.map((achievement, index) => (
                        <div key={index} className="flex items-center space-x-4 p-4 rounded-lg border bg-gradient-to-r from-gray-50 to-blue-50">
                          <div className="text-3xl">{achievement.icon}</div>
                          <div>
                            <p className="font-medium text-gray-900">{achievement.name}</p>
                            <p className="text-sm text-gray-600">{achievement.description}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="settings">
                <Card className="bg-white/90 backdrop-blur-sm shadow-lg border-0">
                  <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle>Profile Settings</CardTitle>
                    <Button
                      onClick={() => isEditing ? handleSave() : setIsEditing(true)}
                      className="bg-academic-blue hover:bg-blue-700"
                    >
                      {isEditing ? "Save Changes" : "Edit Profile"}
                    </Button>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <Label htmlFor="name">Full Name</Label>
                        <Input
                          id="name"
                          value={profileData.name}
                          disabled={!isEditing}
                          onChange={(e) => setProfileData(prev => ({ ...prev, name: e.target.value }))}
                          className="mt-2"
                        />
                      </div>
                      <div>
                        <Label htmlFor="email">Email</Label>
                        <Input
                          id="email"
                          value={profileData.email}
                          disabled={!isEditing}
                          onChange={(e) => setProfileData(prev => ({ ...prev, email: e.target.value }))}
                          className="mt-2"
                        />
                      </div>
                      <div>
                        <Label htmlFor="studentId">Student ID</Label>
                        <Input
                          id="studentId"
                          value={profileData.studentId}
                          disabled={!isEditing}
                          onChange={(e) => setProfileData(prev => ({ ...prev, studentId: e.target.value }))}
                          className="mt-2"
                        />
                      </div>
                      <div>
                        <Label htmlFor="year">Academic Year</Label>
                        <Input
                          id="year"
                          value={profileData.year}
                          disabled={!isEditing}
                          onChange={(e) => setProfileData(prev => ({ ...prev, year: e.target.value }))}
                          className="mt-2"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
