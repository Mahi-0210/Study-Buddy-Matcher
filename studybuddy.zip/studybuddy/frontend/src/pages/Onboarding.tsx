import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Book, User, Target, Clock, Heart, CheckCircle, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { studyBuddyAPI } from "@/api/studyBuddy";
import { StudentProfile } from "@/api/types";

const Onboarding = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    // Step 1: Basic Info
    name: "",
    studentId: "",
    year: "",
    branch: "",
    // Step 2: Academic Goals
    goals: [] as string[],
    // Step 3: Study Preferences
    studyTime: "",
    studyType: "",
    location: "",
    // Step 4: Personality Traits
    traits: [] as string[],
  });

  const totalSteps = 5;

  // Map your form goals to backend format
  const goalMapping: Record<string, string> = {
    "GATE Preparation": "Crack GATE 2025",
    "Competitive Programming": "Win coding hackathon",
    "Hackathons": "Win coding hackathon",
    "Skill Building": "Master machine learning",
    "Course Projects": "Complete course projects",
    "Research Work": "Research and publications"
  };

  // Map study time to backend format
  const studyTimeMapping: Record<string, string> = {
    "early-morning": "early_morning",
    "morning": "morning",
    "afternoon": "afternoon", 
    "evening": "evening",
    "night": "late_night",
    "late-night": "late_night"
  };

  // Map study type to backend format
  const studyTypeMapping: Record<string, string> = {
    "discussion": "auditory",
    "silent": "reading",
    "practical": "kinesthetic",
    "mixed": "visual"
  };

  const goals = [
    "GATE Preparation",
    "Competitive Programming", 
    "Hackathons",
    "Skill Building",
    "Course Projects",
    "Research Work"
  ];

  const personalityTraits = [
    "collaborative",
    "focused", 
    "creative",
    "analytical",
    "patient",
    "motivated",
    "organized",
    "flexible"
  ];

  const handleGoalToggle = (goal: string) => {
    setFormData(prev => ({
      ...prev,
      goals: prev.goals.includes(goal)
        ? prev.goals.filter(g => g !== goal)
        : [...prev.goals, goal]
    }));
  };

  const handleTraitToggle = (trait: string) => {
    setFormData(prev => ({
      ...prev,
      traits: prev.traits.includes(trait)
        ? prev.traits.filter(t => t !== trait)
        : [...prev.traits, trait]
    }));
  };

  const validateCurrentStep = () => {
    switch (currentStep) {
      case 1:
        return formData.name && formData.studentId && formData.year && formData.branch;
      case 2:
        return formData.goals.length > 0;
      case 3:
        return formData.studyTime && formData.studyType && formData.location;
      case 4:
        return formData.traits.length > 0;
      default:
        return true;
    }
  };

  const handleNext = () => {
    if (!validateCurrentStep()) {
      toast.error("Please fill in all required fields");
      return;
    }
    if (currentStep < totalSteps) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleSubmit = async () => {
    if (!validateCurrentStep()) {
      toast.error("Please review your information");
      return;
    }

    setIsSubmitting(true);
    
    try {
      // Transform form data to match API format
      const apiPayload: StudentProfile = {
        student_id: formData.studentId,
        goal: goalMapping[formData.goals[0]] || formData.goals[0], // Use first goal
        preferred_study_time: studyTimeMapping[formData.studyTime] || formData.studyTime,
        study_type: studyTypeMapping[formData.studyType] || formData.studyType,
        personality: formData.traits.map(trait => trait.toLowerCase()),
        year: formData.year,
        branch: formData.branch,
        location: formData.location,
        languages_known: ["English"] // Default value
      };

      console.log("Sending to API:", apiPayload);
      
      // Call your FastAPI backend
      const response = await studyBuddyAPI.findMatch(apiPayload);
      
      // Store results for dashboard
      localStorage.setItem('matchResult', JSON.stringify(response.data));
      localStorage.setItem('userProfile', JSON.stringify({
        ...formData,
        apiPayload
      }));
      
      toast.success("Profile created successfully! Found your study buddy!");
      
      // Navigate to dashboard after short delay
      setTimeout(() => {
        navigate("/dashboard");
      }, 1500);
      
    } catch (error: any) {
      console.error("API Error:", error);
      toast.error(
        error.response?.data?.detail || 
        "Failed to find study buddies. Please try again."
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6 animate-fade-in">
            <div className="text-center mb-8">
              <User className="h-12 w-12 text-academic-blue mx-auto mb-4" />
              <h2 className="text-2xl font-bold font-poppins text-gray-900 mb-2">Basic Information</h2>
              <p className="text-gray-600">Tell us about yourself</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="name">Full Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Enter your full name"
                  className="mt-2"
                  required
                />
              </div>
              <div>
                <Label htmlFor="studentId">Student ID *</Label>
                <Input
                  id="studentId"
                  value={formData.studentId}
                  onChange={(e) => setFormData(prev => ({ ...prev, studentId: e.target.value }))}
                  placeholder="Enter your student ID"
                  className="mt-2"
                  required
                />
              </div>
              <div>
                <Label htmlFor="year">Academic Year *</Label>
                <Select onValueChange={(value) => setFormData(prev => ({ ...prev, year: value }))}>
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Select your year" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="first_year">1st Year</SelectItem>
                    <SelectItem value="second_year">2nd Year</SelectItem>
                    <SelectItem value="third_year">3rd Year</SelectItem>
                    <SelectItem value="final_year">4th Year</SelectItem>
                    <SelectItem value="masters">Masters</SelectItem>
                    <SelectItem value="phd">PhD</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="branch">Branch/Department *</Label>
                <Select onValueChange={(value) => setFormData(prev => ({ ...prev, branch: value }))}>
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Select your branch" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Computer Science">Computer Science</SelectItem>
                    <SelectItem value="Electronics">Electronics & Communication</SelectItem>
                    <SelectItem value="Mechanical">Mechanical Engineering</SelectItem>
                    <SelectItem value="Civil">Civil Engineering</SelectItem>
                    <SelectItem value="Electrical">Electrical Engineering</SelectItem>
                    <SelectItem value="Data Science">Data Science</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6 animate-fade-in">
            <div className="text-center mb-8">
              <Target className="h-12 w-12 text-success-green mx-auto mb-4" />
              <h2 className="text-2xl font-bold font-poppins text-gray-900 mb-2">Academic Goals</h2>
              <p className="text-gray-600">What are you working towards? *</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {goals.map((goal) => (
                <div key={goal} className="flex items-center space-x-3 p-4 rounded-lg border hover:bg-gray-50 transition-colors cursor-pointer">
                  <Checkbox
                    id={goal}
                    checked={formData.goals.includes(goal)}
                    onCheckedChange={() => handleGoalToggle(goal)}
                  />
                  <Label htmlFor={goal} className="cursor-pointer flex-1 font-medium">
                    {goal}
                  </Label>
                </div>
              ))}
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6 animate-fade-in">
            <div className="text-center mb-8">
              <Clock className="h-12 w-12 text-warm-purple mx-auto mb-4" />
              <h2 className="text-2xl font-bold font-poppins text-gray-900 mb-2">Study Preferences</h2>
              <p className="text-gray-600">When and how do you prefer to study? *</p>
            </div>
            <div className="space-y-6">
              <div>
                <Label>Preferred Study Time *</Label>
                <Select onValueChange={(value) => setFormData(prev => ({ ...prev, studyTime: value }))}>
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="When do you study best?" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="early-morning">Early Morning (5-8 AM)</SelectItem>
                    <SelectItem value="morning">Morning (8-12 PM)</SelectItem>
                    <SelectItem value="afternoon">Afternoon (12-5 PM)</SelectItem>
                    <SelectItem value="evening">Evening (5-9 PM)</SelectItem>
                    <SelectItem value="night">Night (9 PM-12 AM)</SelectItem>
                    <SelectItem value="late-night">Late Night (12-5 AM)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Study Type *</Label>
                <Select onValueChange={(value) => setFormData(prev => ({ ...prev, studyType: value }))}>
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="How do you prefer to study?" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="discussion">Discussion Based</SelectItem>
                    <SelectItem value="silent">Silent Study</SelectItem>
                    <SelectItem value="practical">Hands-on/Practical</SelectItem>
                    <SelectItem value="mixed">Mixed Approach</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Preferred Location *</Label>
                <Select onValueChange={(value) => setFormData(prev => ({ ...prev, location: value }))}>
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Where do you like to study?" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Library">Library</SelectItem>
                    <SelectItem value="Home">Home</SelectItem>
                    <SelectItem value="Cafe">Cafe</SelectItem>
                    <SelectItem value="Campus">Campus</SelectItem>
                    <SelectItem value="Online">Online</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6 animate-fade-in">
            <div className="text-center mb-8">
              <Heart className="h-12 w-12 text-study-orange mx-auto mb-4" />
              <h2 className="text-2xl font-bold font-poppins text-gray-900 mb-2">Personality Traits</h2>
              <p className="text-gray-600">Select traits that describe you best *</p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {personalityTraits.map((trait) => (
                <div
                  key={trait}
                  onClick={() => handleTraitToggle(trait)}
                  className={`p-4 rounded-lg border-2 cursor-pointer transition-all duration-200 text-center hover:scale-105 ${
                    formData.traits.includes(trait)
                      ? "border-academic-blue bg-blue-50 text-academic-blue"
                      : "border-gray-200 hover:border-gray-300"
                  }`}
                >
                  <div className="font-medium capitalize">{trait}</div>
                </div>
              ))}
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-6 animate-fade-in">
            <div className="text-center mb-8">
              <CheckCircle className="h-12 w-12 text-success-green mx-auto mb-4" />
              <h2 className="text-2xl font-bold font-poppins text-gray-900 mb-2">Review & Submit</h2>
              <p className="text-gray-600">Confirm your information</p>
            </div>
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Basic Information</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div><span className="font-medium">Name:</span> {formData.name}</div>
                    <div><span className="font-medium">Student ID:</span> {formData.studentId}</div>
                    <div><span className="font-medium">Year:</span> {formData.year}</div>
                    <div><span className="font-medium">Branch:</span> {formData.branch}</div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Goals & Preferences</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div><span className="font-medium">Goals:</span> {formData.goals.join(", ")}</div>
                  <div><span className="font-medium">Study Time:</span> {formData.studyTime}</div>
                  <div><span className="font-medium">Study Type:</span> {formData.studyType}</div>
                  <div><span className="font-medium">Location:</span> {formData.location}</div>
                  <div><span className="font-medium">Traits:</span> {formData.traits.join(", ")}</div>
                </CardContent>
              </Card>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen pt-24 pb-12 px-4">
      <div className="container mx-auto max-w-4xl">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <h1 className="text-2xl font-bold font-poppins text-gray-900">Create Your Profile</h1>
            <span className="text-sm text-gray-500">Step {currentStep} of {totalSteps}</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-academic-blue h-2 rounded-full transition-all duration-500 ease-out"
              style={{ width: `${(currentStep / totalSteps) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Form Content */}
        <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
          <CardContent className="p-8">
            {renderStepContent()}
          </CardContent>
        </Card>

        {/* Navigation Buttons */}
        <div className="flex justify-between mt-8">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentStep === 1}
            className="px-6 py-2"
          >
            Previous
          </Button>
          
          {currentStep < totalSteps ? (
            <Button
              onClick={handleNext}
              className="bg-academic-blue hover:bg-blue-700 px-6 py-2"
              disabled={!validateCurrentStep()}
            >
              Next
            </Button>
          ) : (
            <Button
              onClick={handleSubmit}
              disabled={isSubmitting || !validateCurrentStep()}
              className="bg-success-green hover:bg-green-700 px-6 py-2"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Finding Study Buddies...
                </>
              ) : (
                "Find Study Buddies"
              )}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default Onboarding;
