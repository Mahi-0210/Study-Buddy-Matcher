
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Book, Lightbulb, Clock, MapPin, User, Heart, Filter } from "lucide-react";
import { toast } from "sonner";

const Dashboard = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterGoal, setFilterGoal] = useState("");
  const [filterTime, setFilterTime] = useState("");

  // Mock data for study buddies
  const studyBuddies = [
    {
      id: 1,
      name: "Alex Johnson",
      year: "3rd Year",
      branch: "Computer Science",
      matchScore: 95,
      goals: ["GATE Preparation", "Competitive Programming"],
      studyTime: "Morning (8-12 PM)",
      location: "Library",
      traits: ["Focused", "Analytical", "Motivated"],
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face"
    },
    {
      id: 2,
      name: "Sarah Chen",
      year: "2nd Year",
      branch: "Electronics & Communication",
      matchScore: 88,
      goals: ["Skill Building", "Course Projects"],
      studyTime: "Evening (5-9 PM)",
      location: "Cafe",
      traits: ["Creative", "Collaborative", "Patient"],
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b577?w=150&h=150&fit=crop&crop=face"
    },
    {
      id: 3,
      name: "Raj Patel",
      year: "4th Year",
      branch: "Computer Science",
      matchScore: 82,
      goals: ["Hackathons", "Research Work"],
      studyTime: "Night (9 PM-12 AM)",
      location: "Campus",
      traits: ["Innovative", "Organized", "Flexible"],
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face"
    },
    {
      id: 4,
      name: "Emily Rodriguez",
      year: "1st Year",
      branch: "Mechanical Engineering",
      matchScore: 79,
      goals: ["Course Projects", "Skill Building"],
      studyTime: "Afternoon (12-5 PM)",
      location: "Home",
      traits: ["Curious", "Dedicated", "Friendly"],
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face"
    }
  ];

  const handleSendRequest = (name: string) => {
    toast.success(`Study request sent to ${name}!`);
  };

  const filteredBuddies = studyBuddies.filter(buddy => {
    const matchesSearch = buddy.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         buddy.branch.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesGoal = !filterGoal || filterGoal === "all" || buddy.goals.some(goal => 
      goal.toLowerCase().includes(filterGoal.toLowerCase()));
    const matchesTime = !filterTime || filterTime === "all" || buddy.studyTime.includes(filterTime);
    
    return matchesSearch && matchesGoal && matchesTime;
  });

  return (
    <div className="min-h-screen pt-24 pb-12 px-4">
      <div className="container mx-auto max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold font-poppins text-gray-900 mb-2">
            Find Your Study Buddies
          </h1>
          <p className="text-gray-600">
            Discover students who match your academic goals and study preferences
          </p>
        </div>

        {/* Filters */}
        <Card className="mb-8 bg-white/80 backdrop-blur-sm shadow-lg border-0">
          <CardContent className="p-6">
            <div className="flex items-center gap-4 mb-4">
              <Filter className="h-5 w-5 text-academic-blue" />
              <h3 className="font-semibold text-gray-900">Filter Results</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Input
                placeholder="Search by name or branch..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
              />
              <Select onValueChange={setFilterGoal}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by goal" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Goals</SelectItem>
                  <SelectItem value="GATE">GATE Preparation</SelectItem>
                  <SelectItem value="Programming">Competitive Programming</SelectItem>
                  <SelectItem value="Hackathons">Hackathons</SelectItem>
                  <SelectItem value="Skill">Skill Building</SelectItem>
                  <SelectItem value="Projects">Course Projects</SelectItem>
                  <SelectItem value="Research">Research Work</SelectItem>
                </SelectContent>
              </Select>
              <Select onValueChange={setFilterTime}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by time" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Times</SelectItem>
                  <SelectItem value="Morning">Morning</SelectItem>
                  <SelectItem value="Afternoon">Afternoon</SelectItem>
                  <SelectItem value="Evening">Evening</SelectItem>
                  <SelectItem value="Night">Night</SelectItem>
                </SelectContent>
              </Select>
              <Button 
                variant="outline" 
                onClick={() => {
                  setSearchTerm("");
                  setFilterGoal("");
                  setFilterTime("");
                }}
                className="border-academic-blue text-academic-blue hover:bg-academic-blue hover:text-white"
              >
                Clear Filters
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Results */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredBuddies.map((buddy, index) => (
            <Card 
              key={buddy.id} 
              className="group hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 bg-white/90 backdrop-blur-sm border-0 shadow-lg animate-fade-in"
              style={{animationDelay: `${index * 0.1}s`}}
            >
              <CardHeader className="pb-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-4">
                    <img
                      src={buddy.avatar}
                      alt={buddy.name}
                      className="w-16 h-16 rounded-full object-cover border-2 border-academic-blue/20"
                    />
                    <div>
                      <CardTitle className="text-lg font-semibold text-gray-900">
                        {buddy.name}
                      </CardTitle>
                      <p className="text-sm text-gray-600">{buddy.year} • {buddy.branch}</p>
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="relative inline-flex items-center justify-center w-16 h-16">
                      <svg className="w-16 h-16 transform -rotate-90">
                        <circle
                          cx="32"
                          cy="32"
                          r="28"
                          stroke="#e5e7eb"
                          strokeWidth="4"
                          fill="transparent"
                        />
                        <circle
                          cx="32"
                          cy="32"
                          r="28"
                          stroke="#2563eb"
                          strokeWidth="4"
                          fill="transparent"
                          strokeDasharray={`${2 * Math.PI * 28}`}
                          strokeDashoffset={`${2 * Math.PI * 28 * (1 - buddy.matchScore / 100)}`}
                          className="transition-all duration-1000 ease-out"
                        />
                      </svg>
                      <span className="absolute text-sm font-bold text-academic-blue">
                        {buddy.matchScore}%
                      </span>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">Match Score</p>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                {/* Goals */}
                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    <Book className="h-4 w-4 text-success-green" />
                    <span className="text-sm font-medium text-gray-700">Goals</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {buddy.goals.map((goal, idx) => (
                      <Badge key={idx} variant="secondary" className="text-xs">
                        {goal}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Study Preferences */}
                <div className="space-y-2">
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <Clock className="h-4 w-4 text-warm-purple" />
                    <span>{buddy.studyTime}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <MapPin className="h-4 w-4 text-study-orange" />
                    <span>{buddy.location}</span>
                  </div>
                </div>

                {/* Personality Traits */}
                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    <Heart className="h-4 w-4 text-pink-500" />
                    <span className="text-sm font-medium text-gray-700">Personality</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {buddy.traits.slice(0, 3).map((trait, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {trait}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Action Button */}
                <Button
                  onClick={() => handleSendRequest(buddy.name)}
                  className="w-full bg-academic-blue hover:bg-blue-700 text-white font-medium transition-all duration-200 hover:scale-105"
                >
                  <User className="h-4 w-4 mr-2" />
                  Send Study Request
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredBuddies.length === 0 && (
          <div className="text-center py-12">
            <Lightbulb className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No matches found</h3>
            <p className="text-gray-500">Try adjusting your filters or search terms</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
