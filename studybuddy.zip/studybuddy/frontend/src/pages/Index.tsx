
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Book, Lightbulb, Users, Target, Clock, MapPin } from "lucide-react";

const Index = () => {
  const features = [
    {
      icon: Target,
      title: "Goal Matching",
      description: "Connect with students who share your academic aspirations and study objectives"
    },
    {
      icon: Clock,
      title: "Time Sync",
      description: "Find study partners who match your schedule and preferred study hours"
    },
    {
      icon: Users,
      title: "Personality Fit",
      description: "Get matched based on compatible learning styles and personality traits"
    }
  ];

  const stats = [
    { number: "500+", label: "Study Partnerships" },
    { number: "95%", label: "Success Rate" },
    { number: "50+", label: "Universities" },
    { number: "24/7", label: "Active Matching" }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-academic-blue/10 via-warm-purple/5 to-success-green/10"></div>
        <div className="container mx-auto relative z-10">
          <div className="max-w-6xl mx-auto">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="text-center lg:text-left animate-fade-in">
                <h1 className="text-4xl md:text-6xl font-bold font-poppins text-gray-900 leading-tight mb-6">
                  Find Your Perfect
                  <span className="text-academic-blue block">Study Partner</span>
                </h1>
                <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                  Connect with like-minded students based on your academic goals, study preferences, 
                  and personality traits. Make studying more effective and enjoyable.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                  <Button 
                    asChild
                    size="lg"
                    className="bg-academic-blue hover:bg-blue-700 text-white font-semibold px-8 py-4 rounded-lg text-lg transition-all duration-200 hover:scale-105 hover:shadow-lg"
                  >
                    <Link to="/onboarding">Start Matching</Link>
                  </Button>
                  <Button 
                    asChild
                    variant="outline"
                    size="lg"
                    className="border-academic-blue text-academic-blue hover:bg-academic-blue hover:text-white font-semibold px-8 py-4 rounded-lg text-lg transition-all duration-200 hover:scale-105"
                  >
                    <Link to="/dashboard">Browse Partners</Link>
                  </Button>
                </div>
              </div>
              
              {/* Animated Illustration */}
              <div className="relative animate-fade-in">
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-academic-blue/20 to-warm-purple/20 rounded-3xl blur-3xl"></div>
                  <div className="relative bg-white/80 backdrop-blur-sm rounded-3xl p-8 shadow-2xl">
                    <div className="grid grid-cols-2 gap-6">
                      <div className="flex flex-col items-center p-4 bg-blue-50 rounded-2xl animate-float">
                        <Book className="h-12 w-12 text-academic-blue mb-3" />
                        <p className="font-medium text-gray-800">Study Goals</p>
                      </div>
                      <div className="flex flex-col items-center p-4 bg-green-50 rounded-2xl animate-float" style={{animationDelay: '1s'}}>
                        <Lightbulb className="h-12 w-12 text-success-green mb-3" />
                        <p className="font-medium text-gray-800">Smart Matching</p>
                      </div>
                      <div className="flex flex-col items-center p-4 bg-purple-50 rounded-2xl animate-float" style={{animationDelay: '2s'}}>
                        <Users className="h-12 w-12 text-warm-purple mb-3" />
                        <p className="font-medium text-gray-800">Connect</p>
                      </div>
                      <div className="flex flex-col items-center p-4 bg-orange-50 rounded-2xl animate-float" style={{animationDelay: '3s'}}>
                        <Target className="h-12 w-12 text-study-orange mb-3" />
                        <p className="font-medium text-gray-800">Achieve Goals</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white/50 backdrop-blur-sm">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center animate-bounce-in" style={{animationDelay: `${index * 0.1}s`}}>
                <div className="text-3xl md:text-4xl font-bold text-academic-blue font-poppins mb-2">
                  {stat.number}
                </div>
                <div className="text-gray-600 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold font-poppins text-gray-900 mb-6">
              Why Choose StudyBuddy?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Our intelligent matching system considers multiple factors to find you the perfect study companion
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {features.map((feature, index) => (
              <Card key={index} className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-2 bg-white/80 backdrop-blur-sm border-0 shadow-lg animate-fade-in" style={{animationDelay: `${index * 0.2}s`}}>
                <CardContent className="p-8 text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-academic-blue to-warm-purple rounded-2xl mb-6 group-hover:scale-110 transition-transform duration-300">
                    <feature.icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold font-poppins text-gray-900 mb-4">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-academic-blue to-warm-purple">
        <div className="container mx-auto text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold font-poppins text-white mb-6">
              Ready to Find Your Study Buddy?
            </h2>
            <p className="text-xl text-blue-100 mb-8">
              Join thousands of students who have found their perfect study partners through our platform
            </p>
            <Button 
              asChild
              size="lg"
              className="bg-white text-academic-blue hover:bg-gray-100 font-semibold px-8 py-4 rounded-lg text-lg transition-all duration-200 hover:scale-105 hover:shadow-lg"
            >
              <Link to="/onboarding">Get Started Now</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
