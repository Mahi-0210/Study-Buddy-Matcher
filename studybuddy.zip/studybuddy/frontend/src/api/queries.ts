import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { studyBuddyAPI } from './studyBuddy';
import { StudentProfile } from './types';

// Query keys
export const queryKeys = {
  health: ['health'] as const,
  version: ['version'] as const,
  match: (studentId: string) => ['match', studentId] as const,
};

// Health check query
export const useHealthCheck = () => {
  return useQuery({
    queryKey: queryKeys.health,
    queryFn: () => studyBuddyAPI.checkHealth(),
    refetchInterval: 30000, // Check every 30 seconds
  });
};

// Version info query
export const useVersionInfo = () => {
  return useQuery({
    queryKey: queryKeys.version,
    queryFn: () => studyBuddyAPI.getVersion(),
  });
};

// Match mutation
export const useMatchMutation = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: (studentData: StudentProfile) => studyBuddyAPI.findMatch(studentData),
    onSuccess: (data, variables) => {
      // Cache the result
      queryClient.setQueryData(queryKeys.match(variables.student_id), data);
    },
  });
};
