import { apiClient } from './client';
import { StudentProfile, MatchResponse, HealthResponse, VersionResponse } from './types';

export const studyBuddyAPI = {
  // Health check
  checkHealth: (): Promise<{ data: HealthResponse }> => 
    apiClient.get('/health'),
  
  // Get version info
  getVersion: (): Promise<{ data: VersionResponse }> => 
    apiClient.get('/version'),
  
  // Find study buddy match
  findMatch: (studentData: StudentProfile): Promise<{ data: MatchResponse }> => 
    apiClient.post('/match', studentData),
};
