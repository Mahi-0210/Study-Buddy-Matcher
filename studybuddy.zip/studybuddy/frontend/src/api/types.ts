export interface StudentProfile {
  student_id: string;
  goal: string;
  preferred_study_time: string;
  study_type: string;
  personality: string[];
  year?: string;
  branch?: string;
  location?: string;
  languages_known?: string[];
}

export interface MatchResponse {
  matched_student_id: string | null;
  match_score: number;
  reasoning: {
    goal_similarity: number;
    study_time_match: boolean;
    study_type_match: boolean;
    personality_overlap: string[];
  };
}

export interface HealthResponse {
  status: string;
}

export interface VersionResponse {
  version: string;
  config: Record<string, any>;
  total_students: number;
}
