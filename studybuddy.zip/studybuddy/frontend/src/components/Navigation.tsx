import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Book, Menu, X, Wifi, WifiOff, Loader2 } from "lucide-react";

// Fix: Define the interface properly
interface NavigationProps {
  backendStatus?: 'checking' | 'connected' | 'disconnected';
}

const Navigation = ({ backendStatus = 'checking' }: NavigationProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const navItems = [
    { name: "Home", path: "/" },
    { name: "Find Study Buddies", path: "/dashboard" },
    { name: "Profile", path: "/profile" },
  ];

  const isActive = (path: string) => location.pathname === path;

  const getStatusConfig = () => {
    switch (backendStatus) {
      case 'connected':
        return {
          color: 'bg-green-500',
          text: 'Connected',
          icon: <Wifi className="h-3 w-3" />,
          variant: 'default' as const
        };
      case 'disconnected':
        return {
          color: 'bg-red-500',
          text: 'Offline',
          icon: <WifiOff className="h-3 w-3" />,
          variant: 'destructive' as const
        };
      default:
        return {
          color: 'bg-yellow-500',
          text: 'Checking...',
          icon: <Loader2 className="h-3 w-3 animate-spin" />,
          variant: 'secondary' as const
        };
    }
  };

  const statusConfig = getStatusConfig();

  return (
    <nav className="bg-white/95 backdrop-blur-sm shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2 group">
            <div className="p-2 bg-academic-blue rounded-lg group-hover:scale-110 transition-transform duration-200">
              <Book className="h-6 w-6 text-white" />
            </div>
            <span className="text-xl font-bold font-poppins text-academic-blue">StudyBuddy</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <Link
                key={item.name}
                to={item.path}
                className={`font-medium transition-colors duration-200 hover:text-academic-blue ${
                  isActive(item.path) ? "text-academic-blue" : "text-gray-600"
                }`}
              >
                {item.name}
              </Link>
            ))}
            
            {/* Backend Status Badge */}
            <Badge variant={statusConfig.variant} className="flex items-center space-x-1">
              {statusConfig.icon}
              <span className="text-xs font-medium">{statusConfig.text}</span>
            </Badge>

            <Button 
              asChild
              className="bg-academic-blue hover:bg-blue-700 text-white font-medium px-6 py-2 rounded-lg transition-all duration-200 hover:scale-105"
              disabled={backendStatus === 'disconnected'}
            >
              <Link to="/onboarding">Get Started</Link>
            </Button>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 rounded-lg text-gray-600 hover:text-academic-blue hover:bg-gray-100 transition-colors duration-200"
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden py-4 animate-fade-in">
            <div className="flex flex-col space-y-3">
              {navItems.map((item) => (
                <Link
                  key={item.name}
                  to={item.path}
                  onClick={() => setIsOpen(false)}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors duration-200 ${
                    isActive(item.path)
                      ? "text-academic-blue bg-blue-50"
                      : "text-gray-600 hover:text-academic-blue hover:bg-gray-50"
                  }`}
                >
                  {item.name}
                </Link>
              ))}
              
              {/* Mobile Backend Status */}
              <div className="px-4 py-2">
                <Badge variant={statusConfig.variant} className="flex items-center space-x-1 w-fit">
                  {statusConfig.icon}
                  <span className="text-xs font-medium">{statusConfig.text}</span>
                </Badge>
              </div>

              <Button 
                asChild
                className="bg-academic-blue hover:bg-blue-700 text-white font-medium mx-4 mt-2"
                disabled={backendStatus === 'disconnected'}
              >
                <Link to="/onboarding" onClick={() => setIsOpen(false)}>Get Started</Link>
              </Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navigation;
