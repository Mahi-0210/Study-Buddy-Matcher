text
# Study Buddy Matching Microservice

A FastAPI-based microservice that recommends compatible study buddies for students based on their goals, study preferences, and personality traits.

## Features

- **Offline Operation**: Works completely offline with local data
- **Hybrid Matching**: Uses TF-IDF vectorization for goal similarity and rule-based matching for preferences
- **Configurable**: Flexible configuration for weights and thresholds
- **Fast**: Sub-1-second response time for large datasets
- **Interpretable**: Provides detailed reasoning for matches

## Project Structure

study-buddy/
├── app/
│ ├── main.py # FastAPI application
│ └── matcher.py # Matching algorithm
├── data/
│ └── students.json # Student dataset
├── tests/
│ ├── test_match.py # API tests
│ └── test_matcher.py # Matcher tests
├── config.json # Configuration file
├── schema.json # API response schema
├── requirements.txt # Python dependencies
├── Dockerfile # Container definition
├── docker-compose.yml # Docker compose setup
└── README.md # This file

text

## Quick Start

### Using Docker (Recommended)

1. **Build and run the container:**
docker build -t study-buddy .
docker run -p 8000:8000 study-buddy

text

2. **Or use Docker Compose:**
docker-compose up --build

text

3. **Access the API:**
- API: http://localhost:8000
- Health Check: http://localhost:8000/health
- Documentation: http://localhost:8000/docs

### Local Development

1. **Install dependencies:**
pip install -r requirements.txt

text

2. **Run the application:**
uvicorn app.main:app --reload --port 8000

text

## API Endpoints

### POST /match
Find a study buddy match for a student.

**Request:**
{
"student_id": "stu_9482",
"goal": "Crack GATE 2025",
"preferred_study_time": "early_morning",
"study_type": "visual",
"personality": ["focused", "introvert"]
}

text

**Response:**
{
"matched_student_id": "stu_3921",
"match_score": 0.87,
"reasoning": {
"goal_similarity": 0.9,
"study_time_match": true,
"study_type_match": false,
"personality_overlap": ["focused"]
}
}

text

### GET /health
Health check endpoint.

**Response:**
{
"status": "ok"
}

text

### GET /version
Get version and configuration information.

**Response:**
{
"version": "1.0.0",
"config": { ... },
"total_students": 50
}

text

## Configuration

The `config.json` file controls matching behavior:

{
"version": "1.0.0",
"minimum_match_score": 0.6,
"boost_goal_match": 1.5,
"study_time_weight": 1.2,
"study_type_weight": 1.0,
"personality_weight": 1.0
}

text

- **minimum_match_score**: Minimum score required for a match (0-1)
- **boost_goal_match**: Weight multiplier for goal similarity
- **study_time_weight**: Weight for study time preference match
- **study_type_weight**: Weight for study type match
- **personality_weight**: Weight for personality trait overlap

## Matching Algorithm

The system uses a hybrid approach:

1. **Goal Similarity**: TF-IDF vectorization + cosine similarity
2. **Study Preferences**: Direct boolean matching
3. **Personality**: Jaccard similarity for trait overlap
4. **Final Score**: Weighted combination normalized to 0-1 range

## Testing

Run the test suite:

Run all tests
pytest

Run with coverage
pytest --cov=app

Run specific test file
pytest tests/test_match.py -v

text

## Development

### Adding New Students

Add entries to `data/students.json`:

{
"student_id": "stu_new",
"goal": "Learn web development",
"preferred_study_time": "evening",
"study_type": "project_based",
"personality": ["creative", "collaborative"],
"year": "second_year",
"branch": "Computer Science",
"location": "Delhi",
"languages_known": ["English", "Hindi"]
}

text

### Modifying Matching Logic

Edit `app/matcher.py` to adjust the matching algorithm. Key methods:

- `find_best_match()`: Main matching logic
- `_compute_personality_overlap()`: Personality similarity
- `_validate_config()`: Configuration validation

## Performance

- **Response Time**: < 1 second for 1000+ candidates
- **Memory Usage**: Efficient with TF-IDF vectorization
- **Scalability**: Suitable for datasets up to 10,000 students

## License

MIT License - see LICENSE file for details.